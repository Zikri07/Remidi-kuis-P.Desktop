/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dataram.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import dataram.model.Ram;

public class DBHandler {
    public final Connection conn;

    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addRam(Ram rm){
        String insertMhs = "INSERT INTO `ram`(`id`, `merk`, `jenis`,`tipe`,`kapasitas`,`tanggal_produksi`)"
                + "VALUES (?,?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertMhs);
            stmtInsert.setString(1, rm.getId());
            stmtInsert.setString(2, rm.getMerk());
            stmtInsert.setString(3, rm.getJenis());
            stmtInsert.setString(4, rm.getTipe());
            stmtInsert.setString(5, rm.getKapasitas());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
